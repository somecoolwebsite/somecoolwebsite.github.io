import{_ as r}from"./_layout-1daba58d.js";import{default as t}from"../components/layout.svelte-57e34698.js";export{t as component,r as shared};
