import{default as t}from"../components/pages/_page.svelte-3be67b55.js";export{t as component};
