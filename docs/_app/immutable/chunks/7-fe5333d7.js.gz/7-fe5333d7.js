import{default as t}from"../components/pages/blog/op1/_page.md-78d5be74.js";export{t as component};
