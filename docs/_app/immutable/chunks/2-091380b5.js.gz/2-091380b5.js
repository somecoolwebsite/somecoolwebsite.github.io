import{default as t}from"../components/pages/_page.svelte-fa1c36fc.js";export{t as component};
