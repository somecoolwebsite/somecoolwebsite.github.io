import{default as t}from"../components/pages/blog/tor/_page.md-7f4daaab.js";export{t as component};
