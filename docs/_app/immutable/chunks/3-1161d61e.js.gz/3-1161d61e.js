import{default as t}from"../components/pages/about/_page.svelte-1e78616f.js";export{t as component};
