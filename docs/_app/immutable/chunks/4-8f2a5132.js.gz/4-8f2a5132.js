import{default as t}from"../components/pages/blog/_page.svelte-a2571c18.js";export{t as component};
