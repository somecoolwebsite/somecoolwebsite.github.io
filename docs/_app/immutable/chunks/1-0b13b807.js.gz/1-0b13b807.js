import{default as t}from"../components/error.svelte-08e1ecaa.js";export{t as component};
