import{default as t}from"../components/pages/blog/discord/_page.md-1e783fea.js";export{t as component};
