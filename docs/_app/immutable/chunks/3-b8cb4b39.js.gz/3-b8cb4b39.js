import{default as t}from"../components/pages/about/_page.svelte-9e17bf5d.js";export{t as component};
