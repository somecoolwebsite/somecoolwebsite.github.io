import{default as t}from"../components/pages/_page.svelte-55c5ef39.js";export{t as component};
