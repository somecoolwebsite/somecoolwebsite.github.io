import{default as t}from"../components/pages/blog/_page.svelte-6183e4d8.js";export{t as component};
