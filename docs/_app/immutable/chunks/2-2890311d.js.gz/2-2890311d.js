import{default as t}from"../components/pages/_page.svelte-2d47ec82.js";export{t as component};
