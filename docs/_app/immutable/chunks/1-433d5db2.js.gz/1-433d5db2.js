import{default as t}from"../components/error.svelte-7124c06c.js";export{t as component};
