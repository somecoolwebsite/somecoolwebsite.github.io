import{default as t}from"../components/pages/blog/malware/_page.md-0530f90b.js";export{t as component};
