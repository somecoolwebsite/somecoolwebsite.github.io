window.open("https://somecoolwebsite.github.io/html/harvard.html", "_blank", "width=1000,height=1000,toolbar=0")
