console.log("%cWarning!", "font-size: 27px; color:orange; text-shadow: -3px -3px #e8ba3f, 5px 5px yellow");
